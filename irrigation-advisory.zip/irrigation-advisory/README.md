# irrigation-advisory

## Description

Irrigation Advisory Backend

## Installation

```bash
$ npm install
```

## Setup

1. create a .env file ate thr project root with the following variables

```env

FIREBASE_API_KEY = <FIREBASE_API_KEY>
FIREBASE_AUTH_DOMAIN = <FIREBASE_AUTH_DOMAIN>
FIREBASE_PROJECT_ID = <FIREBASE_PROJECT_ID>
FIREBASE_STORAGE_BUCKET = <FIREBASE_STORAGE_BUCKET>
FIREBASE_MESSAGING_SENDER_ID = <FIREBASE_MESSAGING_SENDER_ID>
FIREBASE_APP_ID = <FIREBASE_APP_ID>
FIREBASE_MEASUREMENT_ID = <FIREBASE_MEASUREMENT_ID>

```

## Running the app

```bash
# development
$ npm start


```

Navigate to port `http://localhost:3000` on postman

## Registration

To add registration details

Send a POST Request to

`http://localhost:3000/registration`

```json
{
  "acreage": 6,
  "crop": "Beans",
  "location": "Ngong",
  "name": "Beans",
  "phone_number": "+254700123457"
}
```

To Fetch All Registration Details

Send a GET Request to

`http://localhost:3000/registration`

## Tips

To add a tip

Send a POST Request to

`http://localhost:3000/tip`

```json
{
  "tip": "Use mulch",
  "location": "Kisii",
  "crop": "Maize"
}
```

To Fetch All Tips

Send a GET Request to

`http://localhost:3000/tip`

To fetch tips by location and crop

Send a GET Request to

`http://localhost:3000/tip/search?location={location}&crop={crop}`

where {location} and {crop} is user defined input
