import { Injectable } from '@nestjs/common';
import { Registration } from 'src/models';
import { RegistrationRepository } from './registration.repository';

@Injectable()
export class RegistrationService {
  constructor(private registrationRepository: RegistrationRepository) {}
  getAll() {
    return this.registrationRepository.getAll();
  }
  addOne(regDto: Registration) {
    return this.registrationRepository.addOne(regDto);
  }
}
