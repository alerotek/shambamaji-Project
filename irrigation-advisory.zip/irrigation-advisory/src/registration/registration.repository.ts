import { Injectable } from '@nestjs/common';
import { collection, getDocs, addDoc } from 'firebase/firestore/lite';
import { getDb } from 'src/db/firebase-admin';
import { Registration } from 'src/models';
const db = getDb();
@Injectable()
export class RegistrationRepository {
  async getAll() {
    const regDetailsCol = collection(db, 'registration_details');
    const regSnapshot = await getDocs(regDetailsCol);
    const regDetails = regSnapshot.docs.map((doc) => doc.data());
    return regDetails;
  }
  async addOne(regDto: Registration) {
    try {
      const docRef = await addDoc(
        collection(db, 'registration_details'),
        regDto,
      );
      return docRef.id;
    } catch (e) {
      return new Error(
        'An error occurred while creating the record, please try again',
      );
    }
  }
}
