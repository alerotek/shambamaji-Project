import { Body, Controller, Get, Post } from '@nestjs/common';
import { Registration } from 'src/models';
import { RegistrationService } from './registration.service';

@Controller('registration')
export class RegistrationController {
  constructor(private registrationService: RegistrationService) {}
  @Post()
  registerFarmer(@Body() createRegistrationDto: Registration) {
    const dto: Registration = {
      ...createRegistrationDto,
    };
    return this.registrationService.addOne(dto);
  }
  @Get()
  getAll() {
    return this.registrationService.getAll();
  }
}
