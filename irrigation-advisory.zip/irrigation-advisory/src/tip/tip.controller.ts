import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { Tip } from 'src/models';
import { TipService } from './tip.service';

@Controller('tip')
export class TipController {
  constructor(private tipService: TipService) {}
  @Post()
  registerFarmer(@Body() createTipDto: Tip) {
    const dto: Tip = {
      ...createTipDto,
    };
    return this.tipService.addOne(dto);
  }
  @Get()
  getAll() {
    return this.tipService.getAll();
  }
  @Get('search')
  findTip(@Query('location') location: string, @Query('crop') crop: string) {
    return this.tipService.findBy({ location, crop });
  }
}
