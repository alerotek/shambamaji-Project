import { Injectable } from '@nestjs/common';
import { Tip } from 'src/models';
import { TipRepository } from './tip.repository';

@Injectable()
export class TipService {
  constructor(private tipRepository: TipRepository) {}
  getAll() {
    return this.tipRepository.getAll();
  }
  addOne(tipDto: Tip) {
    return this.tipRepository.addOne(tipDto);
  }
  findBy(params: { crop: string; location: string }) {
    const { location, crop } = params;
    return this.tipRepository.findByLocationAndCrop(location, crop);
  }
}
