import { Injectable } from '@nestjs/common';
import {
  collection,
  getDocs,
  addDoc,
  query,
  where,
} from 'firebase/firestore/lite';
import { getDb } from 'src/db/firebase-admin';
import { Tip } from 'src/models';
const db = getDb();
const DB_COLLECTION = 'tips';
@Injectable()
export class TipRepository {
  async getAll() {
    const tipDetailsCol = collection(db, DB_COLLECTION);
    const tipSnapshot = await getDocs(tipDetailsCol);
    const tipDetails = tipSnapshot.docs.map((doc) => doc.data());
    return tipDetails;
  }
  async addOne(regDto: Tip) {
    try {
      const docRef = await addDoc(collection(db, DB_COLLECTION), regDto);
      return docRef.id;
    } catch (e) {
      return new Error(
        'An error occurred while creating the record, please try again',
      );
    }
  }
  async findByLocationAndCrop(location: string, crop: string) {
    const tipDetailsCol = collection(db, DB_COLLECTION);
    const q = query(
      tipDetailsCol,
      where('location', '==', location),
      where('crop', '==', crop),
    );
    const tipSnapshot = await getDocs(q);
    const tipDetails = tipSnapshot.docs.map((doc) => doc.data());
    return tipDetails;
  }
}
