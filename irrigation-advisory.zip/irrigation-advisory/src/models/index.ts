export type Registration = {
  name: string;
  location: string;
  crop: string;
  acreage: string;
};

export type Tip = {
  crop: string;
  location: string;
  tip: string;
};
