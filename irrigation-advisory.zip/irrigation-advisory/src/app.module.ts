import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { RegistrationController } from './registration/registration.controller';
import { RegistrationRepository } from './registration/registration.repository';
import { RegistrationService } from './registration/registration.service';
import { TipController } from './tip/tip.controller';
import { TipRepository } from './tip/tip.repository';
import { TipService } from './tip/tip.service';

@Module({
  imports: [],
  controllers: [AppController, RegistrationController, TipController],
  providers: [
    AppService,
    RegistrationService,
    RegistrationRepository,
    TipService,
    TipRepository,
  ],
})
export class AppModule {}
